import { CheckboxCatPipe } from './checkbox-cat.pipe';

describe('CheckboxCatPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckboxCatPipe();
    expect(pipe).toBeTruthy();
  });
});
