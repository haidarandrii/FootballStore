import { CategoryImagePipe } from './category-image.pipe';

describe('CategoryImagePipe', () => {
  it('create an instance', () => {
    const pipe = new CategoryImagePipe();
    expect(pipe).toBeTruthy();
  });
});
