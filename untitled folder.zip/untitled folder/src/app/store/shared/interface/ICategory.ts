export interface ICategory {
    name: string;
    img: string;
}
