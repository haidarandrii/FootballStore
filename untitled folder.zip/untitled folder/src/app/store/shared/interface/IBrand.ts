export interface IBrand {
    name: string;
    id?: number;
}
