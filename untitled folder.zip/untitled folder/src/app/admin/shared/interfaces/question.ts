export interface IQuestion {
    body: string;
    answer?: string;
    id?: number;
}
