import { FiltrProductPipe } from './filtr-product.pipe';

describe('FiltrProductPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltrProductPipe();
    expect(pipe).toBeTruthy();
  });
});
